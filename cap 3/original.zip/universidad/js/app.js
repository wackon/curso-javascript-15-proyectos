// Eliminar de Local Storage
localStorage.clear();